
/*-----------------Zug----------------------------*/
INSERT INTO Zug VALUES (1,'Thomas');
INSERT INTO Zug VALUES (2,'Peter');
INSERT INTO Zug VALUES (3,'Hans');

/*-----------------Wagen----------------------------*/
INSERT INTO Wagen VALUES (1,1,0,20,'A',1);
INSERT INTO Wagen VALUES (2,2,0,20,'A',1);
INSERT INTO Wagen VALUES (3,3,0,20,'A',1);

INSERT INTO Wagen VALUES (4,1,0,20,'A',2);
INSERT INTO Wagen VALUES (5,2,0,20,'A',2);
INSERT INTO Wagen VALUES (6,3,0,20,'A',2);
