# Tips fürs Datenbank Praktikum

## Erste Schritte

* [SQL-Developer](https://www.oracle.com/database/technologies/appdev/sql-developer.html) herunterladen und starten 
* [VPN-Verbindung](https://www.htwg-konstanz.de/rz/dienste/vpn-verbindung/) mit HTWG aufbauen 
* Ändert euer Password
* Öffnet das Beispiel von mir, und spielt ein bisschen rum
* Startet ein locales git-Repo:
  
```
git init
git add --all
git commit -m "My first DB commit"
```

* Startet mit euren eigen CreateTables und Inserts

## Struktur

Die Struktur eurer Dateien könnt ihr frei wählen.
Für einen ersten Start würde ich euch folgende Struktur empfehlen:

* Dateien die beliebig oft aufgerufen werden können
    * CreateTable.sql
    * Inserts.sql
    * Cleanup.sql
* Dateien mit einzelnen Befehlen
    * QueryAndControlls.sql

Durch diese Struktur könnt ihr **innerhalb von Sekunden** eure Komplette Datenbank **Aufräumen** und **Neuaufsetzen**.


## Workflow

* Öffnet die Dateien im SQL-Developer
* Experimentiert herum
* Checkt gute Fortschritte in **git** ein.
* Probiert aus, ob ihr eure Datenbank jeder Zeit neu aufsetzen könnt.