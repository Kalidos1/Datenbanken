
drop table Wagen cascade constraints;
drop table Zug cascade constraints;


/* Quasi "Papierkorb leehren" */
purge recyclebin;